// ResumeRefresh client configuration.
// Keep the OpenRouter API key OUT of this file. It belongs only in the backend .env file.
const APP_CONFIG = Object.freeze({
  PROCESSING_API_URL: 'http://127.0.0.1:8000/process',
  APPS_SCRIPT_URL: 'PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE',
  DEMO_MODE: false,
  MAX_RESUME_BYTES: 8 * 1024 * 1024,
  ALLOWED_RESUME_TYPES: [
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/msword',
    'image/png',
    'image/jpeg',
    'image/webp'
  ]
});
